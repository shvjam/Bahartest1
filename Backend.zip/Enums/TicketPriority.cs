namespace BarbariBahar.API.Enums
{
    public enum TicketPriority
    {
        LOW = 0,
        MEDIUM = 1,
        HIGH = 2,
        URGENT = 3
    }
}
