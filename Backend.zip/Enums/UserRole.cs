namespace BarbariBahar.API.Enums
{
    public enum UserRole
    {
        GUEST = 0,
        CUSTOMER = 1,
        DRIVER = 2,
        ADMIN = 3
    }
}
