namespace BarbariBahar.API.Enums
{
    public enum OrderAddressType
    {
        Origin = 0,        // مبدا
        ORIGIN = 0,        // Alias
        Destination = 1,   // مقصد
        DESTINATION = 1,   // Alias
        Stop = 2          // توقف
    }
}