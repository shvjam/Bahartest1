namespace BarbariBahar.API.Enums;

public enum DiscountType
{
    PERCENTAGE = 0,
    Percentage = 0, // Pascal case
    FIXED = 1,
    Fixed = 1, // Pascal case
    FIXED_AMOUNT = 1, // Alias
    FixedAmount = 1 // Pascal case alias
}