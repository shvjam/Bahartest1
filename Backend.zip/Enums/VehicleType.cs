namespace BarbariBahar.API.Enums
{
    public enum VehicleType
    {
        PICKUP = 0,        // وانت
        NISSAN = 1,        // نیسان
        TRUCK = 2,         // کامیون
        HEAVY_TRUCK = 3    // خاور
    }
}
