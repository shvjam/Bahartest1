namespace BarbariBahar.API.Enums
{
    public enum PaymentMethod
    {
        ONLINE = 0,
        CASH = 1,
        WALLET = 2
    }
}
