namespace BarbariBahar.API.Enums
{
    public enum PackingType
    {
        FULL = 0,
        LARGE_ITEMS = 1,
        SMALL_ITEMS = 2,
        OFFICE = 3
    }
}
