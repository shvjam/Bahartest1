// Re-export ProtectedRoute from common
export { ProtectedRoute } from './common/ProtectedRoute';
